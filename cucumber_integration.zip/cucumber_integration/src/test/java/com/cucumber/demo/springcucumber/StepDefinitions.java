package com.cucumber.demo.springcucumber;

// StepDefinitions.java
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;

public class StepDefinitions {

    @Given("the Spring Boot application is running")
    public void springBootAppIsRunning() {
        // Mock implementation for simplicity
        System.out.println("Spring Boot application is running");
    }

    @When("a request is made to your-endpoint")
    public void makeRequestToYourEndpoint() {
        // Mock implementation for simplicity
        System.out.println("Request made to /your-endpoint");
    }

    @Then("the response should be successful")
    public void responseShouldBeSuccessful() {
        // Mock implementation for simplicity
        System.out.println("Response is successful");
    }
}

