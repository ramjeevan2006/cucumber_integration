package com.cucumber.demo.springcucumber;

import com.cucumber.demo.DemoApplication;
import io.cucumber.spring.CucumberContextConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;

@CucumberContextConfiguration
@ContextConfiguration(classes = DemoApplication.class) // Replace with your main application class
@SpringBootTest
public class SpringCucumberContextConfiguration {
}
