package com.cucumber.demo;

import io.cucumber.spring.CucumberContextConfiguration;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;

// Replace with your main application class
@SpringBootTest
class DemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
